﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class Calc
    {
        protected double resultValue;
        protected double temp;
       // protected string operatorSign;

        List<double> numbers;
        List<string> operatorSign;

        public Calc()
        {
            resultValue = 0.0;

            operatorSign = new List<string>();
            numbers = new List<double>();
        }

        public void SetNumber(string number)
        {
            numbers.Add(double.Parse(number));
        }

        public double GetResult()
        {
            return resultValue;
        }

        public double SignOperator(string sign)
        {
            switch (sign)
            {
                case "+":
                    for(int i=0; i<numbers.Count; i++)
                    {
                        resultValue += numbers[i];
                    }
                    break;

                case "-":
                    //
                    break;

                case "*":
                    //
                    break;
                case "/":
                    //
                    break;
            }

            return resultValue;
        }

        public double OperatorAddition(string add)
        {
            return 0.0;
        }

    }
}
