﻿namespace Calculator_Scientific
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Result = new System.Windows.Forms.TextBox();
            this.button0 = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonAns = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.button_substract = new System.Windows.Forms.Button();
            this.button_multiplication = new System.Windows.Forms.Button();
            this.button_divisor = new System.Windows.Forms.Button();
            this.buttonAC = new System.Windows.Forms.Button();
            this.buttonMR = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button00 = new System.Windows.Forms.Button();
            this.buttonSqrt = new System.Windows.Forms.Button();
            this.buttonPower = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_Result
            // 
            this.textBox_Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Result.Location = new System.Drawing.Point(21, 36);
            this.textBox_Result.Name = "textBox_Result";
            this.textBox_Result.ReadOnly = true;
            this.textBox_Result.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_Result.Size = new System.Drawing.Size(364, 40);
            this.textBox_Result.TabIndex = 0;
            this.textBox_Result.Text = "0";
            // 
            // button0
            // 
            this.button0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button0.BackColor = System.Drawing.Color.DarkGray;
            this.button0.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.Location = new System.Drawing.Point(19, 246);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(68, 37);
            this.button0.TabIndex = 1;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button_dot
            // 
            this.button_dot.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_dot.BackColor = System.Drawing.Color.DarkGray;
            this.button_dot.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_dot.Location = new System.Drawing.Point(167, 246);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(68, 37);
            this.button_dot.TabIndex = 3;
            this.button_dot.Text = "( - )";
            this.button_dot.UseVisualStyleBackColor = false;
            this.button_dot.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(19, 211);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 37);
            this.button1.TabIndex = 4;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button2
            // 
            this.button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(93, 211);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 37);
            this.button2.TabIndex = 5;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button3
            // 
            this.button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(167, 211);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(68, 37);
            this.button3.TabIndex = 6;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button4
            // 
            this.button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button4.BackColor = System.Drawing.Color.DarkGray;
            this.button4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(19, 176);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(68, 37);
            this.button4.TabIndex = 7;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button6
            // 
            this.button6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button6.BackColor = System.Drawing.Color.DarkGray;
            this.button6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(167, 176);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(68, 37);
            this.button6.TabIndex = 9;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button7
            // 
            this.button7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button7.BackColor = System.Drawing.Color.DarkGray;
            this.button7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(19, 141);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(68, 37);
            this.button7.TabIndex = 10;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button9
            // 
            this.button9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button9.BackColor = System.Drawing.Color.DarkGray;
            this.button9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(167, 141);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(68, 37);
            this.button9.TabIndex = 12;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // buttonAns
            // 
            this.buttonAns.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonAns.BackColor = System.Drawing.Color.DarkGray;
            this.buttonAns.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAns.Location = new System.Drawing.Point(241, 246);
            this.buttonAns.Name = "buttonAns";
            this.buttonAns.Size = new System.Drawing.Size(68, 37);
            this.buttonAns.TabIndex = 13;
            this.buttonAns.Text = "Ans";
            this.buttonAns.UseVisualStyleBackColor = false;
            this.buttonAns.Click += new System.EventHandler(this.ButtonAns_Click);
            // 
            // button14
            // 
            this.button14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button14.BackColor = System.Drawing.Color.DarkGray;
            this.button14.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(315, 211);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(68, 72);
            this.button14.TabIndex = 14;
            this.button14.Text = "=";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.asignButton);
            // 
            // button_plus
            // 
            this.button_plus.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_plus.BackColor = System.Drawing.Color.DarkGray;
            this.button_plus.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_plus.Location = new System.Drawing.Point(241, 211);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(68, 37);
            this.button_plus.TabIndex = 15;
            this.button_plus.Text = "+";
            this.button_plus.UseVisualStyleBackColor = false;
            this.button_plus.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // button_substract
            // 
            this.button_substract.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_substract.BackColor = System.Drawing.Color.DarkGray;
            this.button_substract.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_substract.Location = new System.Drawing.Point(241, 141);
            this.button_substract.Name = "button_substract";
            this.button_substract.Size = new System.Drawing.Size(68, 37);
            this.button_substract.TabIndex = 16;
            this.button_substract.Text = "-";
            this.button_substract.UseVisualStyleBackColor = false;
            this.button_substract.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // button_multiplication
            // 
            this.button_multiplication.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_multiplication.BackColor = System.Drawing.Color.DarkGray;
            this.button_multiplication.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_multiplication.Location = new System.Drawing.Point(241, 176);
            this.button_multiplication.Name = "button_multiplication";
            this.button_multiplication.Size = new System.Drawing.Size(68, 37);
            this.button_multiplication.TabIndex = 17;
            this.button_multiplication.Text = "*";
            this.button_multiplication.UseVisualStyleBackColor = false;
            this.button_multiplication.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // button_divisor
            // 
            this.button_divisor.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_divisor.BackColor = System.Drawing.Color.DarkGray;
            this.button_divisor.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_divisor.Location = new System.Drawing.Point(241, 106);
            this.button_divisor.Name = "button_divisor";
            this.button_divisor.Size = new System.Drawing.Size(68, 37);
            this.button_divisor.TabIndex = 18;
            this.button_divisor.Text = "/";
            this.button_divisor.UseVisualStyleBackColor = false;
            this.button_divisor.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // buttonAC
            // 
            this.buttonAC.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonAC.BackColor = System.Drawing.Color.DarkGray;
            this.buttonAC.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAC.Location = new System.Drawing.Point(167, 106);
            this.buttonAC.Name = "buttonAC";
            this.buttonAC.Size = new System.Drawing.Size(68, 37);
            this.buttonAC.TabIndex = 20;
            this.buttonAC.Text = "AC";
            this.buttonAC.UseVisualStyleBackColor = false;
            this.buttonAC.Click += new System.EventHandler(this.AC_button);
            // 
            // buttonMR
            // 
            this.buttonMR.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonMR.BackColor = System.Drawing.Color.DarkGray;
            this.buttonMR.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMR.Location = new System.Drawing.Point(93, 106);
            this.buttonMR.Name = "buttonMR";
            this.buttonMR.Size = new System.Drawing.Size(68, 37);
            this.buttonMR.TabIndex = 21;
            this.buttonMR.Text = "MR";
            this.buttonMR.UseVisualStyleBackColor = false;
            this.buttonMR.Click += new System.EventHandler(this.MR_Button);
            // 
            // buttonMC
            // 
            this.buttonMC.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonMC.BackColor = System.Drawing.Color.DarkGray;
            this.buttonMC.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMC.Location = new System.Drawing.Point(19, 106);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(68, 37);
            this.buttonMC.TabIndex = 22;
            this.buttonMC.Text = "MC";
            this.buttonMC.UseVisualStyleBackColor = false;
            this.buttonMC.Click += new System.EventHandler(this.MC_Button);
            // 
            // button8
            // 
            this.button8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button8.BackColor = System.Drawing.Color.DarkGray;
            this.button8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(93, 141);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(68, 37);
            this.button8.TabIndex = 11;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button5
            // 
            this.button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button5.BackColor = System.Drawing.Color.DarkGray;
            this.button5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(93, 176);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(68, 37);
            this.button5.TabIndex = 23;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // button00
            // 
            this.button00.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button00.BackColor = System.Drawing.Color.DarkGray;
            this.button00.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button00.Location = new System.Drawing.Point(93, 246);
            this.button00.Name = "button00";
            this.button00.Size = new System.Drawing.Size(68, 37);
            this.button00.TabIndex = 24;
            this.button00.Text = ",";
            this.button00.UseVisualStyleBackColor = false;
            this.button00.Click += new System.EventHandler(this.Number_Clicked);
            // 
            // buttonSqrt
            // 
            this.buttonSqrt.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonSqrt.BackColor = System.Drawing.Color.DarkGray;
            this.buttonSqrt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSqrt.Location = new System.Drawing.Point(315, 106);
            this.buttonSqrt.Name = "buttonSqrt";
            this.buttonSqrt.Size = new System.Drawing.Size(68, 37);
            this.buttonSqrt.TabIndex = 27;
            this.buttonSqrt.Text = "sqrt";
            this.buttonSqrt.UseVisualStyleBackColor = false;
            this.buttonSqrt.Click += new System.EventHandler(this.ButtonSqrt_Click);
            // 
            // buttonPower
            // 
            this.buttonPower.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonPower.BackColor = System.Drawing.Color.DarkGray;
            this.buttonPower.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPower.Location = new System.Drawing.Point(314, 141);
            this.buttonPower.Name = "buttonPower";
            this.buttonPower.Size = new System.Drawing.Size(68, 37);
            this.buttonPower.TabIndex = 28;
            this.buttonPower.Text = "^";
            this.buttonPower.UseVisualStyleBackColor = false;
            this.buttonPower.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // button27
            // 
            this.button27.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button27.BackColor = System.Drawing.Color.DarkGray;
            this.button27.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(314, 176);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(68, 37);
            this.button27.TabIndex = 29;
            this.button27.Text = "mod";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.Operator_Clicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(404, 313);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.buttonPower);
            this.Controls.Add(this.buttonSqrt);
            this.Controls.Add(this.button00);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.buttonMC);
            this.Controls.Add(this.buttonMR);
            this.Controls.Add(this.buttonAC);
            this.Controls.Add(this.button_divisor);
            this.Controls.Add(this.button_multiplication);
            this.Controls.Add(this.button_substract);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.buttonAns);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_dot);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.textBox_Result);
            this.Name = "Form1";
            this.Text = "myCalc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Result;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button_dot;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonAns;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.Button button_substract;
        private System.Windows.Forms.Button button_multiplication;
        private System.Windows.Forms.Button button_divisor;
        private System.Windows.Forms.Button buttonAC;
        private System.Windows.Forms.Button buttonMR;
        private System.Windows.Forms.Button buttonMC;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button00;
        private System.Windows.Forms.Button buttonSqrt;
        private System.Windows.Forms.Button buttonPower;
        private System.Windows.Forms.Button button27;
    }
}

